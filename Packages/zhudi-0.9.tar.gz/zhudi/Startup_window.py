# coding=utf8
''' Zhudi provides a Chinese - French dictionnary based on the CFDICT project
    Copyright - 2011 - Ma Jiehong

    Zhudi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Zhudi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Zhudi.  If not, see <http://www.gnu.org/licenses/>.'''

#!/usr/bin/env python2
import pygtk
pygtk.require("2.0")
import gtk, pango, sys

# Input files
pinyin_file = open(sys.argv[1],"r")
pinyin = pinyin_file.readlines()
pinyin_file.closed

zhuyin_file = open(sys.argv[2],"r")
zhuyin = zhuyin_file.readlines()
zhuyin_file.closed

traditional_file = open(sys.argv[3],"r")
traditional = traditional_file.readlines()
traditional_file.closed

simplified_file = open(sys.argv[4],"r")
simplified = simplified_file.readlines()
simplified_file.closed

translation_file = open(sys.argv[5],"r")
translation = translation_file.readlines()
translation_file.closed

# Defaults values
language = "French"
romanisation = "Zhuyin"
hanzi = "Traditional"

# Functions
def set_language(lang):
	global language # Use the value of that variable somewhere else
	language = lang

def display_translation(index,language):
	global translation
	global traditional
	global zhuyin
	global pinyin
	global romanisation
	global simplified
	
	if hanzi == "Traditional":
		hanzi_dic = traditional
	else:
		hanzi_dic = simplified
	
	if romanisation =="Zhuyin":
		romanisation_dic = zhuyin
	else:
		romanisation_dic = pinyin
	tr = translation_box.get_buffer()
	dollars_list = []
	t = translation[index]
	for l in range(len(t)):
		if t[l] == "$":
			dollars_list.append(l)
	temp = 0
	trans = []
	for k in range(len(dollars_list)):
		trans.append(str(k+1)+". "+t[temp:dollars_list[k]])
		temp = dollars_list[k]+1
	trans.append(str(len(dollars_list)+1)+". "+t[temp:len(t)])
	string = ""
	for i in range(len(dollars_list)+1):
		string = string + trans[i]+"\n"
	tr.set_text("Chinois\n"+hanzi_dic[index]+"\n\n"+"Prononciation\n"+romanisation_dic[index]+"\n\nSignification\n"+string) # Display in the Translation box
	
	# "Chinois" in bold
	start_1 = tr.get_iter_at_line(0)
	end_1 = tr.get_iter_at_line(0)
	end_1.forward_to_line_end()
	tr.apply_tag(bold, start_1, end_1)
	
	# Bigger Chinese
	start_c = tr.get_iter_at_line(1)
	end_c = tr.get_iter_at_line(1)
	end_c.forward_to_line_end()
	tr.apply_tag(big, start_c, end_c)
	
	# "Prononciation" in bold
	start_2 = tr.get_iter_at_line(4)
	end_2 = tr.get_iter_at_line(4)
	end_2.forward_to_line_end()
	tr.apply_tag(bold, start_2, end_2)
	
	# "Prononciation" in blue
	start_3 = tr.get_iter_at_line(5)
	end_3 = tr.get_iter_at_line(5)
	end_3.forward_to_line_end()
	tr.apply_tag(blue, start_3, end_3)
	
	# "Signification" in bold
	start_3 = tr.get_iter_at_line(8)
	end_3 = tr.get_iter_at_line(8)
	end_3.forward_to_line_end()
	tr.apply_tag(bold, start_3, end_3)

def find_Chinese(liste,text):
	# Look for not exact matching
	index = []
	total = []
	for k in range(len(liste)): # try in each line of the dic
		if liste[k].count(text) != 0:
			index.append(k)
			total.append(len(liste[k]))
	d = dict(zip(index,total))
	dl = sorted(d.items(), key=lambda (k,v): (v,k))
	index = []
	for i in range(len(dl)): # Keep the sorted candidats
		index.append(dl[i][0])
	return index

def find_French(liste,text):
	# Look for not exact matching
	index = []
	total = []
	for k in range(len(liste)): # try in each line of the dic
		if liste[k].count(text) != 0:
			index.append(k)
			total.append(len(liste[k]))
	d = dict(zip(index,total))
	dl = sorted(d.items(), key=lambda (k,v): (v,k))
	index = []
	for i in range(len(dl)): # Keep the sorted candidats
		index.append(dl[i][0])
	return index
			
def search(searchfield, which):
	global translation
	global traditional
	global language
	global hanzi
		
	w = 40	
	if hanzi == "Traditional":
		hanzi_dic = traditional
	else:
		hanzi_dic = simplified
	if language == "French":
		dic = translation
		dic2 = hanzi_dic
	else:
		dic = hanzi_dic
		dic2 = translation
	text = searchfield.get_text()
	tr = translation_box.get_buffer()
	candidats_list.clear()
	if len(text) == 0:
		tr.set_text("Rien à rechercher…")
		candidats_list.append(["Rien à rechercher…"])
	else:
		if language == "Chinese":
			index = find_Chinese(dic,text)
		else:
			index = find_French(dic,text)
		if len(index) == 0:
			tr.set_text("Aucune correspondance trouvée")
			candidats_list.append(["Aucune correspondance trouvée"])
		else: # Display of the first candidat and its translation
			display_translation(index[which],language)
			if len(dic[index[0]]) > w:
				candidats_list.append(["1. " + dic[index[0]][0:w-1]+"…"])
			else:
				candidats_list.append(["1. " + dic[index[0]][0:len(dic[index[0]])-1]])			
		if len(index) >1:
			for k in range(len(index)-1):
				if len(dic[index[k+1]]) > w:
					candidats_list.append([str(k+2) + ". " + dic[index[k+1]][0:w-1]+"…"])
				else:
					candidats_list.append([str(k+2) + ". " + dic[index[k+1]][0:len(dic[index[k+1]])-1]])
		

def option_clicked(button):
	option_window.connect("destroy",lambda x:option_window.hide())
	option_window.show_all()
	
def set_hanzi(han):
	global hanzi
	hanzi = han

def set_romanisation(rom):
	global romanisation
	romanisation = rom

def candidate_changed(tuple_cursor,searchfield):
	which = tuple_cursor[0][0]
	search(searchfield,which)


# Definition of the options window
option_window = gtk.Window(type=gtk.WINDOW_TOPLEVEL)
option_window.set_size_request(300,180)
option_window.set_title("Options")
option_window.set_position(gtk.WIN_POS_CENTER)

# Hanzi label
hanzi_label = gtk.Label()
hanzi_label.set_text("<big><span font-family=\"linux libertine\">Rechercher / Afficher les caractères :</span></big>") # Should test if the linux Libertine exist on the system first
hanzi_label.set_justify(gtk.JUSTIFY_LEFT)
hanzi_label.set_use_markup(True)

# hanzi box
hanzi_box = gtk.HBox(homogeneous=True, spacing=0)
Traditional = gtk.RadioButton(None,"Traditionnels")
Traditional.connect("clicked", lambda x: set_hanzi("Traditional"))
hanzi_box.pack_start(Traditional,False,False,0)
Simplified = gtk.RadioButton(Traditional,"Simplifiés")
Simplified.connect("clicked", lambda x: set_hanzi("Simplified"))
hanzi_box.pack_start(Simplified,False,False,0)

# Romanisation label
romanisation_label = gtk.Label()
romanisation_label.set_text("<big><span font-family=\"linux libertine\">Prononciation en :</span></big>") # Should test if the linux Libertine exist on the system first
romanisation_label.set_justify(gtk.JUSTIFY_LEFT)
romanisation_label.set_use_markup(True)

# romanisation box
romanisation_box = gtk.HBox(homogeneous=True, spacing=0)
Zhu = gtk.RadioButton(None,"Zhuyin")
Zhu.connect("clicked", set_romanisation)
romanisation_box.pack_start(Zhu,False,False,0)
Pin = gtk.RadioButton(Zhu,"Pinyin")
Pin.connect("clicked", set_romanisation)
romanisation_box.pack_start(Pin,False,False,0)

# Horizontal separator
option_horizontal_separator = gtk.HSeparator()

# Ok button
ok_button = gtk.Button("Ok")
ok_button.connect("clicked", lambda x:option_window.hide())

# Mapping of the option window
loption_vertical_box = gtk.VBox(homogeneous=False, spacing=0)
loption_vertical_box.pack_start(hanzi_label, expand=False, fill=True, padding=3)
loption_vertical_box.pack_start(hanzi_box, expand=False, fill=True, padding=3)
loption_vertical_box.pack_start(romanisation_label, expand=False, fill=True, padding=3)
loption_vertical_box.pack_start(romanisation_box, expand=False, fill=True, padding=3)
loption_vertical_box.pack_start(option_horizontal_separator, expand=False, fill=True, padding=3)
loption_vertical_box.pack_start(ok_button, expand=True, fill=True, padding=3)

# Adding them in the main window
option_window.add(loption_vertical_box)

# Definition of the main window
main_window = gtk.Window(type=gtk.WINDOW_TOPLEVEL)
main_window.set_size_request(800,494) # Gold number ratio
main_window.set_title("Zhudi")
main_window.set_position(gtk.WIN_POS_CENTER)

# Search label
search_label = gtk.Label()
search_label.set_text("<big><span font-family=\"linux libertine\">Zone de recherche</span></big>") # Should test if the linux Libertine exist on the system first
search_label.set_justify(gtk.JUSTIFY_LEFT)
search_label.set_use_markup(True)

# Search field
search_field = gtk.Entry(50)
search_field.set_visible(True)
search_field.connect("activate", search,0)
search_field.set_text("Votre recherche ici…")

# Go, search! button
go_button = gtk.Button(">")
go_button.connect("clicked", lambda x: search(search_field,0))

# Options button
option_button = gtk.Button("+")
option_button.connect("clicked", option_clicked)

# Search + button box
SB_box = gtk.HBox(homogeneous=False, spacing=0)
SB_box.pack_start(search_field,True,True,0)
SB_box.pack_start(go_button,False,False,0)
SB_box.pack_start(option_button,False,False,0)

# Search label zone
frame_search = gtk.Frame()
frame_search.set_label_widget(search_label)
frame_search.add(SB_box)

# Language box
language_box = gtk.HBox(homogeneous=True, spacing=0)
French = gtk.RadioButton(None,"Fr->Ch")
French.connect("clicked", lambda x: set_language("French"))
language_box.pack_start(French,False,False,0)
Chinese = gtk.RadioButton(French,"Ch->Fr")
Chinese.connect("clicked", lambda x: set_language("Chinese"))
language_box.pack_start(Chinese,False,False,0)

# Horizontal separator
horizontal_separator = gtk.HSeparator()

# Candidates part in a list
candidats_list = gtk.ListStore(str)
candidats_tree = gtk.TreeView(candidats_list)
candidats_tree.tvcolumn = gtk.TreeViewColumn('Candidats')
candidats_tree.append_column(candidats_tree.tvcolumn)
candidats_list.cell = gtk.CellRendererText()
candidats_tree.tvcolumn.pack_start(candidats_list.cell, True)
candidats_tree.set_enable_search(False)
candidats_tree.tvcolumn.set_sort_column_id(False)
candidats_tree.set_reorderable(False)
candidats_tree.tvcolumn.set_attributes(candidats_list.cell, text=0)
candidats_tree.connect("cursor-changed", lambda x: candidate_changed(candidats_tree.get_cursor(),search_field))

candidats_scroll = gtk.ScrolledWindow()
candidats_scroll.set_policy(gtk.POLICY_AUTOMATIC, gtk.POLICY_AUTOMATIC) # No horizontal bar, automatic vertical bar
candidats_scroll.set_placement(gtk.CORNER_TOP_LEFT)
candidats_scroll.add_with_viewport(candidats_tree)

frame_candidats = gtk.Frame()
frame_candidats.add(candidats_scroll)

# Vertical separator
vertical_separator = gtk.VSeparator()

# Translation Label
translation_label = gtk.Label()
translation_label.set_text("<big><span font-family=\"linux libertine\">Traduction</span></big>") # Should test if the linux Libertine exist on the system first
translation_label.set_justify(gtk.JUSTIFY_LEFT)
translation_label.set_use_markup(True)

# Translation view
translation_box = gtk.TextView(buffer=None)
translation_box.set_editable(False)
translation_box.set_cursor_visible(False)
translation_box.set_wrap_mode(gtk.WRAP_WORD)
tr = translation_box.get_buffer()
bold = tr.create_tag(weight = pango.WEIGHT_BOLD)
big = tr.create_tag(scale = pango.SCALE_XX_LARGE)
blue = tr.create_tag(foreground="blue")

translation_scroll = gtk.ScrolledWindow()
translation_scroll.set_policy(gtk.POLICY_AUTOMATIC, gtk.POLICY_AUTOMATIC) # No horizontal bar, automatic vertical bar
translation_scroll.set_placement(gtk.CORNER_TOP_LEFT)
translation_scroll.add_with_viewport(translation_box)

frame_translation = gtk.Frame()
frame_translation.set_label_widget(translation_label)
frame_translation.add(translation_scroll)


# Mapping of the main window
left_vertical_box = gtk.VBox(homogeneous=False, spacing=0)
left_vertical_box.pack_start(frame_search, expand=False, fill=True, padding=3)
left_vertical_box.pack_start(language_box, expand=False, fill=True, padding=3)
left_vertical_box.pack_start(horizontal_separator, expand=False, fill=False, padding=10)
left_vertical_box.pack_start(frame_candidats, expand=True, fill=True, padding=7)

right_vertical_box = gtk.VBox(homogeneous=False, spacing=0)
right_vertical_box.pack_start(frame_translation, expand=True, fill=True, padding=7)

horizontal_box = gtk.HBox(homogeneous=False, spacing=0)
horizontal_box.pack_start(left_vertical_box, expand=True, fill=True, padding=5)
horizontal_box.pack_start(vertical_separator, expand=False, fill=False, padding=5)
horizontal_box.pack_start(right_vertical_box, expand=True, fill=True, padding=5)

# Adding them in the main window
main_window.add(horizontal_box)

# Run the GUI
main_window.connect("destroy",gtk.main_quit)
main_window.show_all()
gtk.main()
