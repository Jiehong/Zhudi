''' Zhudi provides a Chinese - French dictionnary based on the CFDICT project
    Copyright - 2011 - Ma Jiehong

    Zhudi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Zhudi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Zhudi.  If not, see <http://www.gnu.org/licenses/>.'''

#!/usr/bin/env python2
import re
import os, sys

# input file
dictionary = sys.argv[1]

# Open the dictionary in text mode, read only
with open(dictionary,mode="r") as dic:
	liste = dic.readlines() # Use the text file as lines
	dic.closed

space_ind = []
pinyin_delimiters = []
translation_delimiters = []
translation = []

# spliting list of the dictionary
pinyin_file = open("pinyin","a")
traditional_file = open("traditional","a")
simplified_file = open("simplified","a")
translation_file = open("translation","a")

for i in liste: # for each line
	del space_ind[:]
	del pinyin_delimiters[:]
	del translation_delimiters[:]
	del translation[:]
	
	if i[0] !="#":
		for k in range(len(i)):
			if i[k] == " ": # look  for spaces
				space_ind.append(k)
			if i[k] =="[": # look for pinyin delimiters
				pinyin_delimiters.append(k)
			if i[k] =="]":
				pinyin_delimiters.append(k)
			if i[k] == "/": # look for translation delimiters
				translation_delimiters.append(k)
		traditional = i[0:space_ind[0]]
		simplified = i[space_ind[0]+1:space_ind[1]]
		pinyin = i[pinyin_delimiters[0]+1:pinyin_delimiters[1]] # works even if the pinyin field is empty
		if len(translation_delimiters) > 2:
			for t in range(len(translation_delimiters)-1):
				translation.append(i[translation_delimiters[t]+1:translation_delimiters[t+1]]) # if many translations
		else:
			translation.append(i[translation_delimiters[0]+1:translation_delimiters[1]])
		pinyin_file.write(pinyin)
		pinyin_file.write("\n")
		traditional_file.write(traditional)
		traditional_file.write("\n")
		simplified_file.write(simplified)
		simplified_file.write("\n")
		for i in range(len(translation)):
			if i >=1:
				translation_file.write("$")
			translation_file.write(translation[i])
		translation_file.write("\n")

pinyin_file.closed
traditional_file.closed
simplified_file.closed
translation_file.closed

# Match and change the pinyin into zhuyin
os.system("/usr/share/zhudi/pin1yin1_to_zhuyin pinyin")
